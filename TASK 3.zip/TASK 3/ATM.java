package code_soft;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.UIManager;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ATM extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPasswordField Pass_inpt;
	protected JLabel usrid_input;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ATM frame = new ATM();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ATM() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 559, 411);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(244, 247, 252));
		contentPane.setForeground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("HELLO CUSTOMER..!");
		lblNewLabel_1.setBounds(10, 335, 160, 25);
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblNewLabel_1);
		
		JLabel user_labl = new JLabel("USER_ID :\r\n\r\n");
		user_labl.setBackground(Color.WHITE);
		user_labl.setBounds(87, 149, 116, 25);
		user_labl.setFont(new Font("Tahoma", Font.BOLD, 16));
		user_labl.setForeground(Color.BLUE);
		contentPane.add(user_labl);
		
		JLabel pass_lble = new JLabel("PASSWORD :\r\n\r\n");
		pass_lble.setBounds(87, 199, 97, 14);
		pass_lble.setForeground(Color.BLUE);
		pass_lble.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(pass_lble);
		
		JButton SUBMT_button = new JButton("SUBMIT");
		SUBMT_button.setBounds(230, 253, 89, 23);
		SUBMT_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(Pass_inpt.getText().equals("9001")) {
					JOptionPane.showMessageDialog(null,"correct password");
					Second_page sp= new Second_page();
					sp.setVisible(true);
					
					
					
				}
				
				
				else if(Pass_inpt.getText().equals("")) {
					JOptionPane.showMessageDialog(null," wrong  password");
					
					
				}
				else {
					JOptionPane.showMessageDialog(null," wrong  password");
					
				}
				
				
			
				
			}
			
		});
		contentPane.add(SUBMT_button);
		
		JTextPane usrid_input = new JTextPane();
		usrid_input.setBackground(SystemColor.window);
		usrid_input.setBounds(232, 149, 122, 20);
		contentPane.add(usrid_input);
		
		Pass_inpt = new JPasswordField();
		Pass_inpt.setBounds(232, 198, 122, 20);
		Pass_inpt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {}
		});
		contentPane.add(Pass_inpt);
		
		JButton btnNewButton = new JButton("CLOSE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame frame =new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frame,"confirm if you","EXIT",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) 
				{
					System.exit(0);
				}
			}
		});
		btnNewButton.setBounds(100, 253, 89, 23);
		contentPane.add(btnNewButton);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 153, 255));
		panel.setBounds(0, 0, 543, 50);
		contentPane.add(panel);
		
		JLabel lblNewLabel_3 = new JLabel("ATM  INTERFACE");
		lblNewLabel_3.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel = new JLabel("ENTER YOUR LOGIN CREDENTIALS:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setBounds(22, 85, 274, 25);
		contentPane.add(lblNewLabel);
	}
}
