package code_soft;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JEditorPane;
import javax.swing.border.TitledBorder;
import javax.swing.SwingConstants;

public class deposit_inpt extends JFrame {

	private static final long serialVersionUID = 1L;
	private JTextField depo_textfield;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		int money;
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					deposit_inpt frame = new deposit_inpt();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public deposit_inpt() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 559, 411);
		JPanel contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 240, 240));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ENTER A AMOUNT TO DEPOSIT ");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(134, 167, 318, 29);
		contentPane.add(lblNewLabel);
		
		depo_textfield = new JTextField();
		depo_textfield.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String money =depo_textfield.getText();
				try {
					int value =Integer.parseInt(money);
				}catch (NumberFormatException ex) {
					Component frame = null;
					JOptionPane.showMessageDialog(frame,"please enter valid  amount","Error",JOptionPane.ERROR_MESSAGE);
					
				}
				
				
			}
		});
		depo_textfield.setBounds(192, 234, 99, 23);
		contentPane.add(depo_textfield);
		depo_textfield.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("$");
		lblNewLabel_1.setForeground(Color.BLUE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 26));
		lblNewLabel_1.setBounds(305, 225, 46, 29);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("EXIT");
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				this.toBack();
				setVisible(false);
				new Second_page().toFront();
				new Second_page().setState(java.awt.Frame.NORMAL);
			}

			private void toBack() {
				// TODO Auto-generated method stub
				
			}
		});
		btnNewButton.setBounds(139, 327, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton depo_button = new JButton("DEPOSIT");
		depo_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				



				JFrame frame =new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frame," YOUR AMOUNT DEPOSITED  ,THANK YOU","EXIT",JOptionPane.PLAIN_MESSAGE)==JOptionPane.PLAIN_MESSAGE) 
				{
					System.exit(0);
				}
			
			
			
			}
		});
		depo_button.setFont(new Font("Tahoma", Font.BOLD, 15));
		depo_button.setForeground(Color.RED);
		depo_button.setBounds(301, 327, 107, 23);
		contentPane.add(depo_button);
		
		JLabel lblNewLabel_2 = new JLabel("DEPOSIT PER TRANSACTION LIMIT  :\r\n\r\n");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2.setForeground(new Color(0, 0, 255));
		lblNewLabel_2.setBounds(10, 81, 318, 29);
		contentPane.add(lblNewLabel_2);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 153, 255));
		panel.setBounds(0, 0, 543, 50);
		contentPane.add(panel);
		
		JLabel lblNewLabel_3 = new JLabel("ATM  INTERFACE");
		lblNewLabel_3.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("2000000 $");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_4.setForeground(Color.BLUE);
		lblNewLabel_4.setBounds(10, 121, 89, 14);
		contentPane.add(lblNewLabel_4);
	}
}
