package code_soft;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import java.awt.LayoutManager;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class bal_page extends JFrame {
	
	private static double balance =9000.00;
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {

        // Create a new JFrame
        

        // Create a label to display the balance
       
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					bal_page frame = new bal_page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public bal_page() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 559, 411);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("TRANSACTION COMPLETE ");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setBounds(180, 86, 254, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("YOUR CURRENT BALANCE :"+balance);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setBounds(159, 211, 255, 19);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("EXIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				setVisible(false);
				new Second_page().toFront();
				new Second_page().setState(java.awt.Frame.NORMAL);
			}
		});
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setBounds(171, 294, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("DONE\r\n");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				JFrame frame =new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frame,"THANK YOU FOR USING OUR ATM","EXIT",JOptionPane.PLAIN_MESSAGE)==JOptionPane.PLAIN_MESSAGE) 
				{
					System.exit(0);
				}
			
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setBounds(301, 294, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel ballabel=new JLabel("current balance:$"+balance);
		ballabel.setHorizontalAlignment(SwingConstants.CENTER);
		ballabel.setText("current balance="+balance);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 153, 255));
		panel.setBounds(0, 0, 543, 50);
		contentPane.add(panel);
		
		JLabel lblNewLabel_3 = new JLabel("ATM  INTERFACE");
		lblNewLabel_3.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		panel.add(lblNewLabel_3);
	}
}
