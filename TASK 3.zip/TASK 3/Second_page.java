package code_soft;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import javax.swing.JLabel;import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.JButton;
import java.util.*;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;


public class Second_page extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Second_page frame = new Second_page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Second_page() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 559, 411);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton BALANCE_CHECK = new JButton("BALANCE CHECK >>\r\n");
		BALANCE_CHECK.setBackground(Color.WHITE);
		BALANCE_CHECK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pin_bal bp= new pin_bal();
				bp.setVisible(true);
				
			}
		});
		BALANCE_CHECK.setFont(new Font("Tahoma", Font.BOLD, 15));
		BALANCE_CHECK.setForeground(SystemColor.desktop);
		BALANCE_CHECK.setBounds(305, 220, 202, 23);
		contentPane.add(BALANCE_CHECK);
		
		JButton DEPOSIT = new JButton("CASH DEPOSIT >>");
		DEPOSIT.setForeground(new Color(0, 0, 0));
		DEPOSIT.setBackground(Color.WHITE);
		DEPOSIT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				pin di= new pin();
				di.setVisible(true);
			}
		});
		DEPOSIT.setFont(new Font("Tahoma", Font.BOLD, 15));
		DEPOSIT.setBounds(305, 102, 202, 23);
		contentPane.add(DEPOSIT);
		
		JButton WITHDRAW = new JButton("CASH WITHDRAW >>\r\n");
		WITHDRAW.setBackground(Color.WHITE);
		WITHDRAW.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pin_with wp= new pin_with();
				wp.setVisible(true);
				
			}
		});
		WITHDRAW.setFont(new Font("Tahoma", Font.BOLD, 15));
		WITHDRAW.setBounds(305, 164, 202, 23);
		contentPane.add(WITHDRAW);
		
		JButton btnNewButton = new JButton("EXIT");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setForeground(Color.RED);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				this.toBack();
				setVisible(false);
				new Second_page().toFront();
				new Second_page().setState(java.awt.Frame.NORMAL);
				
			}

			private void toBack() {
				// TODO Auto-generated method stub
				
			}
		});
		btnNewButton.setBounds(216, 302, 89, 23);
		contentPane.add(btnNewButton);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 153, 255));
		panel.setBounds(0, 0, 543, 50);
		contentPane.add(panel);
		
		JLabel lblNewLabel_3 = new JLabel("ATM  INTERFACE");
		lblNewLabel_3.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		panel.add(lblNewLabel_3);
	}
}
